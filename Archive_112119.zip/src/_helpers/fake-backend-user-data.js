
const users = [{ id: 1, username: 'test@test.com', password: 'test', firstName: 'Test', lastName: 'User' }];

export function getFakeBackendJSONUsers () {
    return users;
}
import React, { Component } from "react";
import "./Home.css";

export default class Home extends Component {
  render() {
    return (
      <div className="Home">
        <div className="lander fluid">
          <span className="thickerType">Giga</span><span className="thinType">Cloud</span>
          <p>Where the Wow Begins!</p>
        </div>
        
       
       </div>
    );
  }
}

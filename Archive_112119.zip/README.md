## Silver Moon
**A Pure React-Grid Dashboard**

Silver Moon is a 100% React-Grid UI treatment that incorporates both PrimeReact widgets in addition to custom ChartJS display elements.

var config = {
    'API_ENDPOINT': 'http://localhost:4000'
};